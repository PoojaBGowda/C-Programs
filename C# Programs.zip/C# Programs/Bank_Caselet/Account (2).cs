﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    public abstract class Account
    {
        public readonly long acc_Number;
        public string name;
        public int balance = 0;
        public Account()
        {
            acc_Number = genRandomnum();
        }

        public abstract void openAccount();
        public abstract void closeAccount();
        public abstract void editAccount();
        public abstract void deposit();
        public abstract void withdrawal();
        public abstract void checkBalance();

        long genRandomnum()
        {
            long acc_num = 0;
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                acc_num = Convert.ToInt64(w);

            }
            return acc_num;
        }
    }
}
