﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*I didnt provide the error handling completely*/

namespace FixedDeposit
{
    class Program
    {
        static void Main(string[] args)
        {
          
            double Principal;
            double[] daysinterest = { 5.50, 6.50, 6.75, 7.00 };
            double[] yrsintrst = { 6.90, 6.95, 6.85, 6.50 };
            Console.WriteLine("Welcome to the banking Management Systems");
            Console.WriteLine(" ");
            Console.WriteLine("Please enter  the Principal amount to calculate the interest");
            Principal = Convert.ToInt32(Console.ReadLine());
            Displaychoicemenuforyrsordys();
            int choice = GetInt("Enter the choice either years or days");

            if (choice == 1)
            {
                int days;
                Console.WriteLine("Choose the range of duration where rate of interest differs");
                DisplayMenufordays();
                int dayschoice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the number of days");
                days = Convert.ToInt32(Console.ReadLine());
                double finalamount = (Principal *  (days ) * daysinterest[dayschoice]) / (100*365);
                Console.WriteLine("The interest is {0}", finalamount);
                Console.WriteLine("The final amount is {0}", (finalamount + Principal));
            }

            else
            {
                int yrs;
                Console.WriteLine("Choose the range of duration where rate of interest differs");
                DisplayMenuforyears();
                int yrschoice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the number of years");
                yrs = Convert.ToInt32(Console.ReadLine());
                double finalamount = (Principal * yrs * yrsintrst[yrschoice]) / 100;
                Console.WriteLine("The interest is {0}", finalamount);
                Console.WriteLine("The final amount is {0}", (finalamount + Principal));
            }
            Console.ReadLine();
        }


        /*To display the menu to choose years or days as duration
         */

        static void Displaychoicemenuforyrsordys()
        {
            string[] menu =
           {
                "1.days",
                "2.years"
           };
            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }
        }


        /*To display the menu for the rateof interest in
         * the case duration is days  */


        static void DisplayMenufordays()
        {

            string[] menu =
             {
               "1. 7 to 45 days",
               "2.46 to 179 days",
               "3.180 days to 210 days",
               "4.211 days to 364 days"
            };
            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }
        }


        /*To display the menu for the rateof interest in
         * the case duration is years
         
             */
        static void DisplayMenuforyears()
        {
            string[] menu =
            {
                "1.1 year",
                "2.2 years",
                "3.3 years",
                "4.3 to 10 years"
            };
            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }
        }

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Number is not in correct format please try again");
            }
            return val;
        }
    }
}
