﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program14
{
    class Program
    {
        String depositor;
        String accNumber;
        String acctype;
        double balance;
        static void Main(string[] args)
        {
            Program p = new Program();

            while (true)
            {
                Console.WriteLine("1.initialize values");
                Console.WriteLine("2.deposit amount");
                Console.WriteLine("3.withdraw amount");
                Console.WriteLine("4. Display the Depositor name and account balance");
                Console.WriteLine("Enter the choice");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter the depositor name,account number,account type and amount");
                        String name = Console.ReadLine();
                        String num = Console.ReadLine();
                        String type = Console.ReadLine();
                        double amt = Convert.ToDouble(Console.ReadLine());
                        p.initialize(name, num, type, amt);
                        break;
                    case 2:
                        Console.WriteLine("Enter the amount to be deposited");
                        double amount = Convert.ToDouble(Console.ReadLine());
                        p.deposit(amount);
                        break;
                    case 3:
                        Console.WriteLine("Enter the amount to withdraw");
                        double amount1 = Convert.ToDouble(Console.ReadLine());
                        p.withdraw(amount1);
                        break;
                    case 4:
                        p.display();
                        break;
                }
            }
            Console.ReadLine();
        }
        public void initialize(String name, String number, String type, double amount)
        {
            depositor = name;
            accNumber = number;
            acctype = type;
            if (amount >= 0)
            {
                balance = amount;
            }
            else
                Console.WriteLine("Error: Invalid amount!");
        }
        public void deposit(double amount)
        {
            if (amount > 0)
            {
                balance += amount;
            }
            else
                Console.WriteLine("Error: Invalid amount!");
        }

        public void withdraw(double amount)
        {
            if (amount > 0 && amount < balance)
            {
                balance -= amount;
            }
            else
                Console.WriteLine("Error: Insufficient found or invalid amount!");
        }
        public void display()
        {
            Console.WriteLine("Depositor name: " + depositor);
            Console.WriteLine("Account balance: " + balance);
        }
    }
}