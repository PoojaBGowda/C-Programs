﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class Program
    {
        static void Main(string[] args)
        {
            int f1 = 0, f2 = 1, f3 = 0;
            Console.WriteLine(" first 10 numbers of the Fibonacci Series are");
            Console.WriteLine(f1);
            Console.WriteLine(f2);
            for(int i=0;i<8;i++)
            {
                f3 = f1 + f2;
                Console.WriteLine(f3);
                f1 = f2;
                f2 = f3;
            }

            Console.ReadLine();
        }
    }
}
