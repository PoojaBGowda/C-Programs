﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program8
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Test();
            Console.ReadLine();

        }
        static bool isPrime(int n)
        {
          
            if (n <= 1) return false;

            for (int i = 2; i <= n / 2; i++)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
        public void Test()
        {
            Console.WriteLine("Enter the number to check prime or not");
            int a = int.Parse(Console.ReadLine());
            bool result = isPrime(a);
            if (result)
                Console.WriteLine($"{a} is prime number");
            else
                Console.WriteLine($"{a} is not prime number");

        }
    }
}
