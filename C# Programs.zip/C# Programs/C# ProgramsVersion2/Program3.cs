﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program3
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            while (true)
            {
                try
                {
                    Console.WriteLine("Enter the number");
                    int num = Convert.ToInt32(Console.ReadLine());
                    int temp = num;
                    while (num > 0)
                    {
                        int rem = num % 10;
                        sum = sum + rem;
                        num = num / 10;
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"The sum of {temp} = {sum}");
                    Console.ResetColor();
                    Console.ReadLine();
                    break;
                }
                catch (FormatException e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();

                }
            }
            
        }
    }
}
