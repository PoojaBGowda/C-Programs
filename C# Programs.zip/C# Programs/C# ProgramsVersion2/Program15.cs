﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program15
{
    class Shape
    {
        public static double a;
        public static double b;

        public void Set(double p,double q)
        {
            a = p;
            b = q;
        }
        public virtual void DisplayArea()
        {
            Console.WriteLine();
        }
    
    }

    class Triangle:Shape
    {
        public override void DisplayArea()
        {
            double area = (a * b) / 2;
            Console.WriteLine($"Area of triangle ={area}");
        }
    }

    class Rectangle:Shape
    {
        public override void DisplayArea()
        {
            double area = a * b;
            Console.WriteLine($"Area of triangle ={area}");
        }

    }



    class Program
    {
        static void Main(string[] args)
        {
            Shape s = new Shape();
            Triangle t = new Triangle();
            Rectangle r = new Rectangle();
            s.Set(12, 8);
            t.DisplayArea();
            r.DisplayArea();
            Console.ReadLine();
        }
    }
}
