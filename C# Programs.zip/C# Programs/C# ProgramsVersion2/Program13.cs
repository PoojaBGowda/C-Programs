﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program13
{
    class LongFormDate
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the day");
            int dd = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the month");
            int mm = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the year");
            int yyyy = int.Parse(Console.ReadLine());
            DateTime UserDate = new DateTime(yyyy, mm, dd);
            Console.WriteLine($"User date is {dd} {mm} {yyyy}");

            DateTime now = DateTime.Now;
            Console.WriteLine(now);
            Console.WriteLine("The diffrence in seconds is" + UserDate.Subtract(now).Seconds);
            Console.WriteLine("The diffrence in minutes is" + UserDate.Subtract(now).Minutes);
            Console.WriteLine("The diffrence in hours is" + UserDate.Subtract(now).Hours);

            Console.WriteLine("The diffrence in days is" + UserDate.Subtract(now).Days);

            Console.WriteLine("This day  is " + UserDate.ToLongDateString());
                        
            Console.ReadLine();
        }
    }
}
