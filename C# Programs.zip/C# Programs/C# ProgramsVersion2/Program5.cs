﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program5
{
    class Program
    {
        static void Main(string[] args)
        {

            Double dollar, rupee, BPounds, val1, val2;
            Console.WriteLine("Enter the Dollar Amount :");
            dollar = Getval();
            Console.WriteLine("Enter the Dollar Value in rupees ");
            val1 = Getval();
            rupee = dollar * val1;
            Console.WriteLine("{0} Dollar = {1} Rupees", dollar, rupee);

            Console.WriteLine("Enter the Dollar Value in British pounds");
            val2 = Getval();
            BPounds = dollar * val2;
            Console.WriteLine("{0} Dollar = {1}  British pounds", dollar, BPounds);

            Console.ReadLine();
        }
        public static double Getval()
        {
            double val = 0;
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The entered number is not in correct format please try again");
                Console.ResetColor();
            }
            return val;
        }
    }
}

