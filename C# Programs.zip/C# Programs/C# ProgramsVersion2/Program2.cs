﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Program2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, number, fact;
            while (true)
            {
                try
                {
                    Console.WriteLine("Enter the Number");
                    number = int.Parse(Console.ReadLine());
                    fact = number;
                    for (i = number - 1; i >= 1; i--)
                    {
                        fact = fact * i;
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\nFactorial of Given Number is: " + fact);
                    Console.ResetColor();

                    Console.ReadLine();
                    break;
                }
                catch (FormatException e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();
                }
            }
            

        }
    }
}

