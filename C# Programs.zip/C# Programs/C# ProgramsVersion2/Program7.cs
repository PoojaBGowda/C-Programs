﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter size of array");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] numbers = new int[n];
            int sum = 0;
            int median = 0;
            Console.WriteLine("enter numbers");
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }
            

            Console.WriteLine("mean of array");
            for (int i = 0; i < numbers.Length; i++)
            {
                sum = sum + numbers[i];
            }
            int mean = sum / (numbers.Length);
            Console.WriteLine(mean);

           // median of array
            Array.Sort(numbers);

           
            int len = numbers.Length;
            if (len % 2 == 0)
            {
                median = (numbers[len / 2] + numbers[((len - 1) / 2)]);
            }
            else
          
                median = numbers[(numbers.Length) / 2];
          
            Console.WriteLine($"median={median}");
         
            double sumOfnumbers = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                sumOfnumbers += (numbers[i] - mean) * (numbers[i] - mean);
            }
            double standarddeviation = Math.Sqrt(sumOfnumbers / numbers.Length);
            Console.WriteLine($"standard deviation={standarddeviation}");
            Console.WriteLine("mode of array");
            int maxvalue = 0;
            int maxcount = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                int count = 0;
                for (int j = 0; j < numbers.Length; j++)
                {
                    if (numbers[i] == numbers[j])
                    {
                        count++;
                    }
                    if (count > maxcount)
                    {
                        maxcount = count;
                        maxvalue = numbers[i];
                    }
                }
            }
            Console.WriteLine( maxvalue);
            Console.ReadLine();


        }
    }
}


