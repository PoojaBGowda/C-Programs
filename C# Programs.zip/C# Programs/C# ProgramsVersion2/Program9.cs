﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;

namespace ConsoleApplication2
{
    class Program
    {
        static int choice = 0;
        static int count1 = 0, count2 = 0, count3 = 0;
        static void Main(string[] args)
        {
            Console.WriteLine("Enter no of elements you want to insert ");

            int n = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[n];
            int i = 0;
            Console.WriteLine("Enter the elements: \n");
            while (i < n)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
                i++;
            }
            Console.WriteLine("Choose the sorting criteria");
            Console.WriteLine("1.Ascending \n 2.Descending");
            choice = Convert.ToInt32(Console.ReadLine());
            Console.ReadLine();
            Stopwatch stopwatch = new Stopwatch();
            switch (choice)
            {
                case 1:
                    stopwatch.Start();
                    Normal_sort(arr);
                    stopwatch.Stop();
                    TimeSpan t1 = stopwatch.Elapsed;
                   
                    Console.WriteLine("Time elapsed(Normal Sort)={0}", t1);
                    SpeechSynthesizer speaker1 = new SpeechSynthesizer();
                    speaker1.Speak("Time elapsed for Normal Sort is" + t1);

                    stopwatch.Start();
                    bubbleSort(arr);
                    stopwatch.Stop();
                    TimeSpan t2 = stopwatch.Elapsed;
                    
                    Console.WriteLine("Time elapsed(Bubble Sort)={0}", t2);
                    SpeechSynthesizer speaker2 = new SpeechSynthesizer();
                    speaker2.Speak("Time elapsed for Normal Sort is" + t2);

                    stopwatch.Start();
                    selectionSort(arr);
                    stopwatch.Stop();
                    TimeSpan t3 = stopwatch.Elapsed;
                    
                    Console.WriteLine("Time elapsed(Selection Sort)={0}", t3);
                    SpeechSynthesizer speaker3 = new SpeechSynthesizer();
                    speaker3.Speak("Time elapsed for Normal Sort is" + t3);


                    stopwatch.Start();
                    InsertionSort(arr);
                    stopwatch.Stop();
                    TimeSpan t4 = stopwatch.Elapsed;
                    
                    Console.WriteLine("Time elapsed(Insertion Sort)={0}", t4);
                    SpeechSynthesizer speaker4 = new SpeechSynthesizer();
                    speaker4.Speak("Time elapsed for Normal Sort is" + t4);

                    break;

                case 2:
                    stopwatch.Start();
                    Normal_sort(arr);
                    stopwatch.Stop();
                    TimeSpan t5 = stopwatch.Elapsed;
                    Console.WriteLine("Time elapsed(Normal Sort)={0}", t5);
                    SpeechSynthesizer speaker5 = new SpeechSynthesizer();
                    speaker5.Speak("Time elapsed for Normal Sort is" + t5);

                    stopwatch.Start();
                    bubbleSort(arr);
                    stopwatch.Stop();
                    TimeSpan t6 = stopwatch.Elapsed;
                    Console.WriteLine("Time elapsed(Bubble Sort)={0}", t6);
                    SpeechSynthesizer speaker6 = new SpeechSynthesizer();
                    speaker6.Speak("Time elapsed for Normal Sort is" + t6);

                    stopwatch.Start();
                    selectionSort(arr);
                    stopwatch.Stop();
                    TimeSpan t7 = stopwatch.Elapsed;
                    Console.WriteLine("Time elapsed(Selection Sort)={0}", t7);
                    SpeechSynthesizer speaker7= new SpeechSynthesizer();
                    speaker7.Speak("Time elapsed for Normal Sort is" + t7);

                    stopwatch.Start();
                    InsertionSort(arr);
                    stopwatch.Stop();
                    TimeSpan t8 = stopwatch.Elapsed;
                    Console.WriteLine("Time elapsed(Insertion Sort)={0}", t8);
                    SpeechSynthesizer speaker8 = new SpeechSynthesizer();
                    speaker8.Speak("Time elapsed for Normal Sort is" + t8);

                    break;
            }
            Console.ReadLine();
        }

        private static void Normal_sort(int[] arr)
        {
            if (choice == 1)
            {
                Array.Sort(arr);
            }
            else
            {
                Array.Sort(arr);
                Array.Reverse(arr);
            }
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(" " + arr[i]);
            }
        }

        public static void bubbleSort(int[] ar)
        {
            for (int i = ar.Length - 1; i >= 0; i--)
            {
                for (int j = 1; j <= i; j++)
                {
                    if (choice == 1)
                    {
                        if ((ar[j - 1] > ar[j]))
                        {
                            int temp = ar[j - 1];
                            ar[j - 1] = ar[j];
                            ar[j] = temp;
                        }
                    }

                    else
                    {
                        if (ar[j - 1] < ar[j])
                        {
                            int temp = ar[j - 1];
                            ar[j - 1] = ar[j];
                            ar[j] = temp;
                        }
                    }
                    count1++;

                }
            }
            for (int i = 0; i < ar.Length; i++)
            {
                Console.Write(" " + ar[i]);
            }
            Console.WriteLine("Number of operations to complete the task={0}", count1);

        }

        public static void selectionSort(int[] ar)
        {
            for (int i = 0; i < ar.Length - 1; i++)
            {
                int min = i;
                for (int j = i + 1; j < ar.Length; j++)
                    if (choice == 1)
                    {
                        if (ar[j] < ar[min]) min = j;
                        {
                            int temp = ar[i];
                            ar[i] = ar[min];
                            ar[min] = temp;
                        }
                    }
                    else
                    {
                        if (ar[j] > ar[min]) min = j;
                        {
                            int temp = ar[i];
                            ar[i] = ar[min];
                            ar[min] = temp;
                        }
                    }
                count2++;
            }
            for (int i = 0; i < ar.Length; i++)
            {
                Console.Write(" " + ar[i]);
            }
            Console.WriteLine("Number of operations to complete the task={0}", count2);

        }

        private static void InsertionSort(int[] arr)
        {
            if (choice == 1)
            {
                for (int i = 1; i < arr.Length; i++)
                {
                    int item = arr[i];
                    int ins = 0;

                    for (int j = i - 1; j >= 0 && ins != 1;)
                    {
                        if (item < arr[j])
                        {
                            arr[j + 1] = arr[j];
                            j--;
                            arr[j + 1] = item;
                        }
                        else ins = 1;
                        count3++;
                    }
                }
            }
            else
            {
                for (int i = 1; i > arr.Length; i++)
                {
                    int item = arr[i];
                    int ins = 0;
                    for (int j = i - 1; j >= 0 && ins != 1;)
                    {
                        if (item < arr[j])
                        {
                            arr[j + 1] = arr[j];
                            j--;
                            arr[j + 1] = item;
                        }
                        else ins = 1;
                        count3++;
                    }
                }
            }



            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");

            }
            Console.WriteLine("Number of operations to complete the task={0}", count3);

        }

    }

}

