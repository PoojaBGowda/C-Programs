﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseleteOnBookShop
{
    interface ISalestax
    {
        void calculate_SalesTax(List<BooksOnAsubject> a);
    }
    class NotAvailable : ApplicationException
    {
        public string msg1()
        {
            return "Not Available";
        }
    }
    class NOBook : ApplicationException
    {
        public string msg2()
        {
            return "No Book found";
        }
    }
}
