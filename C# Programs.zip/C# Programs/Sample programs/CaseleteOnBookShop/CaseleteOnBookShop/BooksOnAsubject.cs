﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseleteOnBookShop
{
    class BooksOnAsubject : Book, ISalestax
    {

        public long isbnNumber;
        public string title;
        public string author;
        public double price;
        public Boolean inStock;


        public override string ToString()
        {
            return isbnNumber.ToString() + "\t" + title.ToString() + "\t" + author.ToString() + "\t" + price.ToString() +
                "\t" + inStock.ToString();
        }
        public void getNum(List<BooksOnAsubject> a, BooksOnAsubject b)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("Enter isbnNumber");
                    long num = Convert.ToInt64(Console.ReadLine());
                    BooksOnAsubject result = a.Find(item => item.isbnNumber == num);
                    if (result != null)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Book already exists");
                        Console.ResetColor();
                    }
                    else
                    {
                        b.isbnNumber = num;
                        break;
                    }
                }
                catch (FormatException e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();

                }
            }   
           
        }

       
        public void Add_book(List<BooksOnAsubject> a)
        {

            BooksOnAsubject b = new BooksOnAsubject();
            do
            {
               getNum(a,b);

            if (b.isbnNumber.ToString().Length == 13)
            {
                Console.WriteLine("Enter the title, author, price");
                b.title = Console.ReadLine();
                b.author = Console.ReadLine();
                b.price = Convert.ToDouble(Console.ReadLine());
                a.Add(b);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Book inserted successfully");
                Console.ResetColor();
                break;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Please Enter 13 digits");
                Console.ResetColor();
            }
            } while (true);

        }

        public long formatCheck()
        {
            long booknum;
            while (true)
            {
                try
                {
                    Console.Write("Enter book number: ");
                    booknum = Convert.ToInt64(Console.ReadLine());
                    return booknum;
                }
                catch (FormatException e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();
                }
                return 1;
            }
        }
        public void delete_book(List<BooksOnAsubject> book1)
        {
            long booknum1=formatCheck();
           
                BooksOnAsubject result = book1.Find(item => item.isbnNumber == booknum1);

                if (result != null)
                {
                    book1.Remove(result);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Book is deleted");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("No Books exist with that book number");
                    Console.ResetColor();
                }
           
        }
        public void display_allbooks(List<BooksOnAsubject> a)
        {
            Console.WriteLine("ISBN NUMBER\t TITLE\t     AUTHOR\tPRICE\tINSTOCK");
            Console.WriteLine("---------------------------------------------------------");
            foreach (BooksOnAsubject b1 in a)
            {
                Console.WriteLine(b1.ToString());
            }
        }
        public void modify_price(List<BooksOnAsubject> modify)
        {
            int newprice;
            long booknum1=formatCheck();

            try
            {
                BooksOnAsubject result = modify.Find(item => item.isbnNumber == booknum1);
                if (result != null)
                {
                    Console.Write("Enter New Price: ");
                    newprice = Convert.ToInt32(Console.ReadLine());
                    result.price = newprice;
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Book price is modified Successfully");
                    Console.ResetColor();
                }
                else
                {
                    throw (new NOBook());
                }
            }
            catch (NOBook ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.msg2());
                Console.ResetColor();
            }
        }

        public void searchByAuthor(List<BooksOnAsubject> a)
        {
            Console.WriteLine("Enter the name of the Author");
            string author1 = Console.ReadLine().ToUpper();

            BooksOnAsubject result = a.Find(item => item.author ==author1);

            if (result != null)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Book details is given below");
                Console.ResetColor();
                Console.WriteLine($"isbn Number :{ result.isbnNumber}\n  Title     :{result.title}\n  Author    :{result.author}\n  Price     :{ result.price}\n  inStock   :{ result.inStock}\n");

            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("sorry!!!currently We do not have books written by the above mentioned author...");
                Console.ResetColor();
            }

        }
        public void searchByTitle(List<BooksOnAsubject> a)
        {

            try
            {
                Console.WriteLine("Enter Title");
                string t = Console.ReadLine();

                BooksOnAsubject result = a.Find(item => item.title == t);

                if (result != null)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"isbn Number :{ result.isbnNumber}\n  Title     :{result.title}\n  Author    :{result.author}\n  Price     :{ result.price}\n  inStock   :{ result.inStock}\n");
                    Console.ResetColor();
                }
                else
                {
                    throw (new NOBook());
                }
            }
            catch (NOBook ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.msg2());
                Console.ResetColor();
            }
            
            }
        public void check_available(List<BooksOnAsubject> a)
        {
            try
            {
                Console.WriteLine("Enter Title");
                string t = Console.ReadLine();

                BooksOnAsubject result = a.Find(item => item.title == t);

                if (result != null)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" Book is Available");
                    Console.ResetColor();
                    Console.WriteLine($"isbn Number :{ result.isbnNumber}\n  Title     :{result.title}\n  Author    :{result.author}\n  Price     :{ result.price}\n  inStock   :{ result.inStock}\n");
                }
                else
                {
                    throw (new NotAvailable());
                }
            }
            catch (NotAvailable ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex.msg1());
                Console.ResetColor();
            }

        }

        public void calculate_SalesTax(List<BooksOnAsubject> a)
        {
            int booknum;
            int count = 0;

            Console.Write("Enter Book number: ");
            booknum = Convert.ToInt32(Console.ReadLine());
            foreach (BooksOnAsubject b1 in a)
            {
                if (b1.isbnNumber == booknum)
                {
                    double salestax = 0.045 * b1.price;
                    Console.WriteLine("Sales Tax:Rs.{0}", salestax);
                    count++;
                }

            }
            if (count == 0)
                Console.WriteLine("No Books exist with that book number");


        }
    
    }
}
