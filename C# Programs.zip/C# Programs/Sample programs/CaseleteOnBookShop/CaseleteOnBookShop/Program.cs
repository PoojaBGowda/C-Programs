﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseleteOnBookShop
{
    class program
    {
        static void Main(string[] args)
        {
            string confirm;
            List<Book> book = new List<Book>()
            {
                new Book(1,"Physics",5),       
                new Book(2, "Chemistry", 5),   
                new Book(3, "Mathematics", 5)         
            };

            Console.WriteLine("SUBJECT ID\t SUBJECT\t COUNT OF BOOKS");
            Console.WriteLine("---------------------------------------------------------");
            foreach (Book b4 in book)
            {
                Console.WriteLine(b4.ToString());
            }
            Console.WriteLine("---------------------------------------------------------");
            List<BooksOnAsubject> a = new List<BooksOnAsubject>()
            {
                new BooksOnAsubject(){isbnNumber= 6756454465751,title="Physics1",author="A",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6756454464751, title="Physics2",author="B",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6756454463751, title="Physics3",author="C",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6756454461751, title="Physics4",author="D",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6756454468751, title="Physics5",author="E",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6755555565751,title="Chemistry1",author="F",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6756777776575, title="Chemistry2",author="G",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6756454469951, title="Chemistry3",author="H",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6756454422751, title="Chemistry4",author="I",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6888584465751, title="Chemistry5",author="J",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6756644665751,title="Mathematics1",author="K",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6757657565751, title="Mathematics2",author="L",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6759677865751, title="Mathematics3",author="M",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6758434546541, title="Mathematics4",author="N",price=250 ,inStock=true},
                new BooksOnAsubject(){isbnNumber= 6757567567681, title="Mathematics5",author="O",price=250 ,inStock=true}
            };

            
            Console.WriteLine("ISBN NUMBER\t TITLE\t     AUTHOR\tPRICE\tINSTOCK");
            Console.WriteLine("---------------------------------------------------------");
            BooksOnAsubject b = new BooksOnAsubject();
            foreach (BooksOnAsubject b1 in a)
            {
                Console.WriteLine(b1.ToString());
            }
            do
            {
                Console.WriteLine("---------------------------------------------------------");
                Console.WriteLine(" 1:Add Book\n 2:Delete Book\n 3:Display all books\n 4:Modify the price of a book\n 5:Search by author\n 6:Search by title\n 7:Calculate Sales Tax\n 8:Check Availability");
                Console.WriteLine("---------------------------------------------------------");
                int i = GetInt("Enter the choice");
                switch (i)
                {
                    case 1:
                        b.Add_book(a);
                        break;
                    case 2:
                        b.delete_book(a);
                        break;
                    case 3:
                        b.display_allbooks(a);
                        break;
                    case 4:
                        b.modify_price(a);
                        break;
                    case 5:
                        b.searchByAuthor(a);
                        break;
                    case 6:
                        b.searchByTitle(a);
                        break;
                    case 7:
                        b.calculate_SalesTax(a);
                        break;
                    case 8:
                        b.check_available(a);
                        break;
                   
                }
                Console.WriteLine("Enter to Y or y continue");
                confirm = Console.ReadLine().ToUpper();

            } while (confirm == "Y");
        }
        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The entered number is not in correct format please try again");
                Console.ResetColor();
            }
            return val;
        }
    }
}
