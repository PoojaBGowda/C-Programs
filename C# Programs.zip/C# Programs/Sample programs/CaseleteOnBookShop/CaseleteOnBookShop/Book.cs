﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseleteOnBookShop
{
    class Book
    {
        public string subject { get; set; }
        public readonly int subject_id; 
        public int countOfBooks;
        public Book()
        {
        }
        public Book(int subject_id,string Subject,int countOfBooks)
        {
            this.subject = Subject;
            this.subject_id = subject_id;
            this.countOfBooks = countOfBooks;

        }

        public override string ToString()
        {
            return subject_id.ToString() + "\t\t" + subject.ToString() + "\t\t" + countOfBooks.ToString();
        }
    }
}
