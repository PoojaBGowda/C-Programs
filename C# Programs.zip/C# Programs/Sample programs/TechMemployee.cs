﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechMEmployee
{
    class Test
    {
        static void Main(string[] args)
        {
            Displaymenu();
            int ch = Convert.ToInt32(Console.ReadLine());
            switch (ch) {
                case 1: object_creation();
                    break;
                case 2:object_creation1();
                    break;
            }
        }

        static void Displaymenu() {
            Console.WriteLine("1.SalEmp");
            Console.WriteLine("2.ConEmp");
            Console.WriteLine("Enter the choice");
        }

        public  static void object_creation()
        {
            SalEmp se = new SalEmp();
            se.Details();
            Console.WriteLine(se.id);
            Console.WriteLine(se.fname);

        }
        public static void object_creation1()
        {
            ConEmp ce = new ConEmp();
            ce.Details();
        }
    }

    class ConEmp :IPerson
    {
        public int id;
        public string fname;
        public string lname;
        public  void Details()
        {
            id = Convert.ToInt32(Console.ReadLine());
            fname = Console.ReadLine();
            lname = Console.ReadLine();
            emp();
        }
        public void emp()
        {
            Console.WriteLine("Hi I am TechM employee");
            Console.WriteLine("Hi I am {0} {1}", this.fname, this.lname);
            Console.ReadLine();
        }

    }

    class SalEmp :IPrivilege, IPerson
    {

        public int id;
        public string fname;
        public string lname;
       public  void Details()
        {
            id = Convert.ToInt32(Console.ReadLine());
            fname = Console.ReadLine();
            lname = Console.ReadLine();
            emp();
            }
        
        public void clubmem()
        {

            Console.WriteLine("Hi I am {0} {1}", this.fname, this.lname + "I am member of club");
            Console.ReadLine();
        }

        public void emp()
        {
            Console.WriteLine("Hi I am TechM employee");
            clubmem();
        }
    }

    interface IPerson
    {

        void emp();
    }


    interface IPrivilege
    {
        void clubmem();

    }
}
