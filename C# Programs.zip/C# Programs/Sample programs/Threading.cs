﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threading
{
    class Program
    {
        static volatile bool isThreadStop = false;
        static void Main(string[] args)
        {
            Console.WriteLine("Main method started..");
            Thread th= new Thread(new ThreadStart(LongMethod));
            th.Start();
            for(int i=0;i<10;i++)
            {
                Console.WriteLine($"Inside main method -Executing {i} items");
                Thread.Sleep(3000);
                if(i==3)
                {
                    isThreadStop = true;
                    //th.Abort();
                }
            }


            Console.WriteLine("Main method ended....");
            Console.ReadLine();
        }

        static void LongMethod()
        {
            try
            {

                Console.WriteLine("LongMethod  started..");
                for (int i = 0; i < 20; i++)
                {
                    if (!isThreadStop)
                    {
                        Console.WriteLine($"[Debug]  {isThreadStop}");
                        Console.WriteLine($"Inside LongMethod  -Executing {i} items");
                        Thread.Sleep(3000);
                    }
                    else
                        break;

                }
            }

            catch(ThreadAbortException ex)
            {
                Console.WriteLine($"Exception due to {ex.Message}");
            }
            
            Console.WriteLine("LongMethod  ended....");
            Console.ReadLine();

        }
    }
}  
