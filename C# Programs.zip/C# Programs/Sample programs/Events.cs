﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace WindowsapplicationfromConsole
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {

            Window window = new Window();
            window.Height = 500;
            window.Width = 600;
            window.Title = "My First windows  Form Application ";


            Button btn = new Button();
            btn.Height = 23;
            btn.Width = 29;
            btn.Content = "click";
            window.Content = btn;
            btn.Click += (s, e) => { MessageBox.Show("Hi "); };//using lamda expression
            btn.Click += Btn_Click;//using method

            Application app = new Application();
            app.Run(window);
          }

        private static void Btn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hello");
        }
    }
}
