﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop;
using Excel = Microsoft.Office.Interop.Excel;



namespace Topickrandomnumber
{
    class MainClass
    {
        static List<int> students = new List<int>();

        public static void Main(String[] args)
        {
            Console.WriteLine("Enter the numer of students");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the numer of rows");
            int rows = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the numer of columns");
            int columns = Convert.ToInt32(Console.ReadLine());
            string confirm;

            do
            {
                Console.WriteLine("1. Upload Excel file of GID's");
                Console.WriteLine("2. Enter The GID's Manually");
                Console.WriteLine("Enter the choice");
                int choice = GetInt();

                switch (choice)
                {
                    case 1:
                        GID_sfromfile(num, rows, columns);
                        break;
                    case 2:

                        Console.WriteLine("Enter the GID");

                        for (int i = 0; i < num; i++)
                        {
                            int gid = GetInt();
                            students.Add(gid);
                        }
                        GID_sfromUser(num, rows, columns);
                        break;
                }
                Console.WriteLine("Please enter 'y' to continue..");
                confirm = Console.ReadLine().ToUpper();
            } while (confirm == "Y");

        }

        public static void GID_sfromUser(int num, int rows, int columns)
        {
            int size = rows * columns;

            List<int> randomList = new List<int>(size);
            Random random = new Random();
            while (students.Count > 0)
            {
                int randomIndex = random.Next(0, students.Count); //Choose a random object in the list
                randomList.Add(students[randomIndex]); //add it to the new, random list
                students.RemoveAt(randomIndex); //remove to avoid duplicates
            }
            for (int i = num; i < size; i++)
            {
                randomList.Add(0);
            }
            Console.Clear();
            // To print the output inthe table format
            Console.WriteLine("The seating Arrangement is:");

            for (int j = 1; j <= columns; j++)
            {
                Console.Write("Col{0}\t", j);

            }
            Console.WriteLine();
            int k = 0;

            for (int i = 0; i < rows; i++)
            {

                for (int j = 0; j < columns; j++)
                {
                    Console.Write(randomList[k] + " \t");
                    k++;
                }
                Console.WriteLine();
            }

            Console.ReadLine();
        }

        public static void GID_sfromfile(int num, int rows, int columns)
        {
            try
            {
                openFile();
                GID_sfromUser(num, rows, columns);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        static int GetInt()
        {
            int val = 0;

            while (true)
            {

                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.WriteLine(" Enter the correct number");
            }
            return val;
        }

        static void openFile()
        {
            int rowCount;
            int colCount;

            Console.WriteLine("Enter the path of Excel File");
            string mysheet = Console.ReadLine();
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(mysheet);
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
            Excel.Range xlRange = xlWorksheet.UsedRange;

            rowCount = xlRange.Rows.Count;
            colCount = xlRange.Columns.Count;

            for (int i = 1; i <= rowCount; i++)
            {
                for (int j = 1; j <= colCount; j++)
                {
                    //write the value to the console
                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                    {
                        students.Add(Convert.ToInt32(xlRange.Cells[i, j].Value2));
                    }
                }
            }
        }
    }
}

