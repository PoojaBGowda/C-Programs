﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //1.Display menu
            //2.user choice to perform the operation
            //3.read the two inputs from the user
            //4.perform the operation
            //5.display the result
            bool repeat = true;
            int num1 = 0;
            int num2 = 0;
            while (repeat)
            {
                Displaymenu();
                int choice = GetInt("Enter your choice");
                if (choice != 0)
                {
                     num1 = GetInt("Enter first operand");
                     num2 = GetInt("Enter second operand");
                }
                    int result = 0;
                    switch (choice)
                    {
                        case 0:
                            repeat = false;
                            break;
                        case 1:
                            result = Add(num1, num2);
                            break;
                        case 2:
                            result = Sub(num1, num2);
                            break;
                        case 3:
                            result = Mul(num1, num2);
                            break;
                        case 4:
                            result = Div(num1, num2);
                            break;
                    }
                    Console.WriteLine(result);
                    Console.ReadLine();
                    Console.Clear();
                
            }
            
        }

        static void Displaymenu()
        {

            string[] menuOptions = {
            "0.Exit",
            "1.Add",
            "2.Sub",
            "3.Mul",
            "4.Div"
            };

            foreach (string item in menuOptions)
            {
                Console.WriteLine(item);
            }

        }

        static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.WriteLine("Invalid Input please try again");
            }
            return val;
        }
        private static int Add(int num1, int num2)
        {
            return num1 + num2;
        }

        private static int Sub(int num1, int num2)
        {
            return num1 - num2;
        }

        private static int Mul(int num1, int num2)
        {
            return num1 * num2;
        }

        private static int Div(int num1, int num2)
        {
            return num1 / num2;
        }

    }
}
