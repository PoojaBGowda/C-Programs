﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Read_Line_Key
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine(a);
            Console.WriteLine("Enter a Character");
            ConsoleKeyInfo c = Console.ReadKey();
            Console.ReadLine();
            Console.WriteLine("Character=" + c.Key.ToString());
            Console.WriteLine("Enter a string");
            String s=Console.ReadLine();
            Console.WriteLine("String="+s);


        }
    }
}
