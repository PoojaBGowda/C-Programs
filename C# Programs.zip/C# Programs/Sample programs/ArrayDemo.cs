﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 1, 2, 3, 4, 5 };
            int sum = 0;

            foreach (int i in a)
            {
                sum += i;
            }
            Console.WriteLine("sum={0}", sum);


            //int[,] a = new int[3,3];

            //int[][] b = new int[2][];
            //int[,] a = new int[3,2];
            //a[0, 0] = 1;
            //a[0, 1] = 1;
            //a[1, 0] = 1;
            //a[1, 1] = 1;
            //a[2, 0] = 1;
            //a[2, 1] = 1;
            //foreach (int i in a)
            //{
            //    Console.WriteLine(i); 
            //}


            // Declare and initialize a matrix of size 2 x 4
            int[,] matrix =
            {
                {1, 2, 3, 4}, // row 0 values
                {5, 6, 7, 8}, // row 1 value
            };
            // Print the matrix on the console
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    Console.Write(matrix[row, col]);
                }
                Console.WriteLine();
            }
        }
    }
}
