﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethod
{

    static class ExtensionDemo
    {
        public static void Sayhello(this Program p)
        {
            Console.WriteLine("Extension method");
        }
       
    }
    class Program
    {

        void Sayhello()
        {
            Console.WriteLine("instance method");
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Sayhello();
            ExtensionDemo.Sayhello(p);
           

        }
    }
}
