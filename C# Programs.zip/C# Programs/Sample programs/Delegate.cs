﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    class Program
    {
        public  delegate T gendel <T>(T item1,T item2);
        public delegate int Mydelegate(int x, int y); 
      
        static void Main(string[] args)
        {
            int i = 5;int j = 6;
            Mydelegate delegate1 = delegate (int x, int y )
            {
                Console.WriteLine("The sum of x and y is:"+x+y);
                return x + y;
            };
            Console.WriteLine("THe anonymous method is called");
            Console.ReadLine();
            gendel<int> del = null;
            del += sum;
            gendel<float> del1 = null;
            del1 += sub;
            Func<int, int, float> funcdel = sub1;
        }
        static int sum(int x,int y)
        {
            return x + y;
        }
        static float sub(float x, float y)
        {
            return x - y;
        }

        static float sub1(int x, int y)
        {
            return x - y;
        }
    }
}
